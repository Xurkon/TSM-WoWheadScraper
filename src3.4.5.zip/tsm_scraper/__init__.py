"""TSM Item ID Scraper - Import item IDs into TradeSkillMaster for Project Ascension."""

__version__ = "1.0.0"
