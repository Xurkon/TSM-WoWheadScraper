"""TSM Wowhead Scraper - Import item IDs into TradeSkillMaster from Wowhead databases."""

__version__ = "1.0.0"
