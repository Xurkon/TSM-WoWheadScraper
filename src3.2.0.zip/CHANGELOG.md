# TSM Wowhead Scraper - Changelog

**Created by [Xurkon](https://github.com/Xurkon)**

## [v3.2.0] - 2025-12-12

### Bug Fixes

- **Fixed Delete Group**: Group deletion now properly removes groups with nested structures (Mailing, Auctioning, etc.)
  - Previous regex-based deletion couldn't handle nested braces in TSM's retail format
  - Now uses brace-counting algorithm that tracks depth to find group boundaries
  - Groups are now fully removed from both file and UI

- **Fixed Delete Items**: Item deletion now works correctly
  - Fixed logic that caused early return before file was saved
  - Items are properly removed when selecting "No" to "Keep Items?"
  - Log shows accurate count of items removed

- **Fixed Create Default Groups**: Groups now properly save for retail TSM format
  - Retail TSM stores groups as root-level keys in `TradeSkillMasterDB`, not in a `["groups"]` sub-table
  - Groups are now correctly inserted and persist after restart

- **Fixed Rename Group**: Verified working with special characters in group names

### New Features

- **Copy Log Button**: Added 📋 button next to log folder (📁) in log header
  - Copies current session log to clipboard for easy sharing
  - Only copies visible session content, not the full persistent log file

- **Improved Delete Dialog**: Two-step confirmation for safer deletion
  1. First dialog confirms group deletion with clear warning about item removal
  2. Second dialog asks if items should be kept (uncategorized) or removed entirely
  - Log shows detailed counts: groups removed, subgroups removed, items removed

- **Improved Group Hierarchy Display**: Better visual distinction between levels
  - Top-level groups: 📁 12px bold, gold text, dark background
  - Category groups: 📂 11px bold, 20px indent
  - Slot groups: 📄 10px normal, 40px indent
  - Deeper levels: • 9px gray, progressive indentation
  - Case-insensitive alphabetical sorting at all levels

### Developer Changes

- Refactored `delete_group()` in `lua_writer.py` to use line-by-line brace-counting
- Fixed `ensure_group_exists()` to insert groups at `TradeSkillMasterDB` root level
- Added `items_found` counter separate from `items_removed` for accurate tracking
- Added `copy_log_to_clipboard()` method to GUI
- Added left padding (`padx`) for proper visual indentation in group hierarchy

---

## [v3.1.0] - 2025-12-12

### New Features

- **Auto-Create Default Groups**: New "✨ Create Default Groups" button generates 145 TSM groups from Wowhead's category hierarchy
  - **Direct injection** into TSM SavedVariables (no copy/paste needed!)
  - Includes warning confirmation dialog (intended for empty profiles)
  - Creates backup before modifying, skips existing groups
  - Full coverage: Armor (4 types × 8 slots), Weapons, Consumables, Gems, Recipes (13 professions), Containers, and more

- **Group Management**: Right-click any group in sidebar for context menu:
  - 📝 **Rename Group** - Rename with automatic item reference updates
  - ➕ **Add Sub-Group** - Create child groups
  - 🗑️ **Delete Group** - Remove with confirmation (creates backup)

- **Profile Management**: Store and switch between up to 5 TSM SavedVariables profiles
  - Profile dropdown in sidebar for quick switching between WoW accounts
  - 🗑️ Remove profile button (removes from list, not file)
  - Clickable 📁 folder icon opens SavedVariables folder

### Developer Additions

- **Wowhead Filter Reference**: Complete filter documentation in `wowhead_scraper.py` docstring:
  - Binding filters (BoP=2, BoE=3, BoU=4)
  - 26 slot IDs, armor type IDs, weapon type IDs
  - Category URLs (armor, weapons, consumables, gems, recipes, etc.)
  - Special filters (Toys, Faction)
- **TSM_GROUP_STRUCTURE**: New constant defining complete category hierarchy
- **generate_tsm_groups()**: New function to produce TSM-compatible group paths

---

## [v3.0.0] - 2025-12-11

### Wowhead-Only Release

This version focuses exclusively on Wowhead databases for maximum compatibility with official World of Warcraft servers.

- **NEW: Bind Type Filter**: Full dropdown filter for item binding types:
  - All Items (no filter)
  - Bind on Equip (BoE) - tradeable on AH
  - Bind on Pickup (BoP) - soulbound when acquired
  - Bind on Use (BoU) - bound when consumed
  - Bind to Account (BoA) - heirloom items
  - Quest Items
  - Warbound - Warband shared (Retail)
  - No Binding - unrestricted items
- **Removed**: Private server database options (Ascension, Turtle WoW) - use [TSM-Scraper](https://github.com/Xurkon/TSM-Scraper) for those
- **Streamlined UI**: Cleaner database selection with only Wowhead options
- **Default**: Now defaults to Wowhead (WotLK) on startup

### Supported Databases

- Wowhead WotLK (`wowhead.com/wotlk`)
- Wowhead TBC (`wowhead.com/tbc`)
- Wowhead Classic Era (`classic.wowhead.com`)
- Wowhead Cata (`wowhead.com/cata`)
- Wowhead MoP Classic (`wowhead.com/mop-classic`)
- Wowhead Retail (`www.wowhead.com`)

---

## [v2.1.3] - 2025-12-11

### Added

- **Recipe Categories**: Added 9 recipe categories (Alchemy, Blacksmithing, Cooking, Enchanting, Engineering, First Aid, Jewelcrafting, Leatherworking, Tailoring).
- **Additional Consumables**: Added Bandage and Scroll categories.
- **GUI Category Checkboxes**: Category group headers (⚔ Weapons, ⚗ Consumables, etc.) are now checkboxes that auto-select all items in the category when clicked.

### Fixed

- **Wowhead Subclass Filtering**: Fixed critical bug where consumable/trade goods categories were returning all items instead of filtering by subclass.
  - Elixirs now correctly return 93 items instead of 911 (all consumables).
  - Added `CATEGORY_URL_MAP` with pretty URLs for all categories (weapons, consumables, trade goods, gems, recipes).
  - Added `scrape_by_name()` method for unified category scraping using server-side filtered URLs.
- **Small Category Scraping**: Lowered array detection threshold from 5000 to 500 chars to catch small categories like First Aid recipes (11 items).
- **GUI Wowhead Integration**: Fixed `on_server_changed` to properly assign `WowheadScraper` to `self.scraper`.
- **Category Collapse/Expand**: Fixed expand behavior to properly place items after header frame.

## [v2.1.2] - 2025-12-11

- **Fixed:** Compiled executable using `gui_modern.py` correctly instead of the legacy `gui.py`. The interface is now the correct Modern/CustomTkinter version.

## [v2.1.1] - 2025-12-11

- **Fixed:** Resolved Wowhead scraping for Retail, Cataclysm, and MoP by updating CSS selectors.
- **Fixed:** Verified compatibility for all 6 supported Wowhead game versions.

## [v2.1.0] - 2025-12-11

### Wowhead Multi-Version Support

- **Database Server Selection**: Fully functional for all Wowhead options:
  - Wowhead WotLK (`wowhead.com/wotlk`)
  - Wowhead TBC (`wowhead.com/tbc`)
  - Wowhead Classic Era (`classic.wowhead.com`)
  - Wowhead Cata (`wowhead.com/cata`)
  - Wowhead MoP Classic (`wowhead.com/mop-classic`)
  - Wowhead Retail (`www.wowhead.com`)

- **TSM Format Selection**: New dropdown to control output format:
  - **WotLK 3.3.5a**: Uses `item:ID:0:0:0:0:0:0` format
  - **Retail (Official TSM)**: Uses `i:ID` format for retail TSM

### Documentation & Build

- **Compiled Executable**: Added standalone `TSM Scraper.exe` build using PyInstaller.
- **GitHub Documentation**: Created modern `README.MD` and `docs/index.html` (GitHub Pages).

### Bug Fixes

- **Fixed dialog cut-off issue**: `ThemedMessageBox` now auto-sizes height (220-500px) based on message length, ensuring Yes/No buttons are always visible

### Technical Changes

- Added `WowheadScraper` class with `game_version` parameter (`retail`, `wotlk`, `classic`)
- Updated `lua_parser.py` to handle both Classic (`item:ID:...`) and Retail (`i:ID`) formats
- Added `is_retail_format()` and `get_format_type()` helper methods
- Added `on_format_changed()` handler for TSM format selection

---

## [v2.0.0] - 2025-12-10

### Selective Category Import

- Scrape results now display checkboxes for each category
- Categories with NEW items are checked by default
- Uncheck categories to exclude them from import
- Validation: warns if no categories selected or no new items in selection

#### Smart Group Auto-Selection

- After scraping, automatically detects matching TSM group
- Highlights selected group with cyan background
- Attempts to scroll to selected group in list
- Falls back to showing "Target group (will be created)" if group doesn't exist

#### Themed Message Dialogs

- Created `ThemedMessageBox` class for styled popups
- Replaced all `messagebox` calls with themed versions
- Dialogs now match the application theme colors

#### Font Size Controls

- Added font size properties to Theme dataclass:
  - `font_size_header` (default: 14px)
  - `font_size_label` (default: 12px)
  - `font_size_body` (default: 11px)
  - `font_size_small` (default: 10px)
  - `font_size_tiny` (default: 9px)
- Added font size sliders to Theme Editor (Settings → scroll down)

### Improvements

#### Import Workflow

- Import confirmation now shows selected target group name
- Success message updated: "If WoW is running, restart it to see changes"
- Added safety check with friendly message when trying to import without scraping
- **Multi-category import**: When importing multiple categories with different target groups, shows list of each category and its destination group

#### Group Selection

- TSM groups in right sidebar are now clickable buttons
- Selected group is visually highlighted
- Shows "Selected:" label with current target group

### Bug Fixes

- Fixed header spanning all 3 columns in new layout
- Fixed references to removed `results_text` widget
- Fixed auto-select to run even with 0 new items found

### Technical Changes

- Added `group_buttons_registry` for tracking group button widgets
- Added `results_checkboxes` dict for tracking result category selections
- Renamed `create_sidebar` to `create_left_sidebar`
- Added `create_center_panel` and `create_right_sidebar` methods
- Added helper methods:
  - `update_results_with_checkboxes()`
  - `get_selected_import_categories()`
  - `highlight_group_button()`
  - `scroll_to_group_button()`
  - `auto_select_scrape_group()`
  - `select_import_group()`
  - `on_server_changed()`
